ROMAN ARENA — PAINTERLY SPECIAL MOVE SPRITES (V54)

WHAT YOU GET
- preview.html: open locally to see all 13 special move animations.
- contact_preview.png: side-by-side reference for all 13.
- fight/specials/painted/: 26 transparent PNG sprite atlases (13 full cast sequences + 13 impact/effect layers).
- qa_report.json: frame segmentation diagnostics.

GITHUB: ONE ZIP UPLOAD
1. Rename THIS ZIP to painted-specials-v54.zip if it is named otherwise.
2. Open https://github.com/MarcosAurelious/marcos-garcia-author/tree/main/fight
3. Choose Add file > Upload files, and upload painted-specials-v54.zip in the fight folder.
4. Commit to main. A GitHub Actions workflow installs all 26 assets automatically.
5. Confirm the action 'Install painted Roman Arena special sprites' is green.
6. Open https://marcosaurelious.github.io/marcos-garcia-author/fight/ and refresh.

IMPORTANT: These are painterly raster prototypes extracted from an illustration reference. The frames are new images, not individually hand-drawn source poses. Test transitions and proportions in the browser before considering the art pass final. Existing movement animation remains unchanged.
